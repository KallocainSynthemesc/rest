package com.kilian.api;

import java.util.List;
import java.util.Objects;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.kilian.dao.PersonList;
import com.kilian.model.Person;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

@RestController
@RequestMapping("persons")
public class PersonResource
{

	@GetMapping
	public List<Person> findAll() {
		return PersonList.persons;
	}

	@GetMapping(value="/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Person findByIdJson(@PathVariable("id") Integer id) {
		return PersonList.persons.stream()
				.filter((e) -> e.getPersonNum() == id)
				.findFirst()
				.orElse(new Person()); //empty person
	}
	
	@GetMapping(value="/{id}", produces = MediaType.APPLICATION_XML_VALUE)
	public Person findByIdXml(@PathVariable("id") Integer id) {
		return PersonList.persons.stream()
				.filter((e) -> e.getPersonNum() == id)
				.findFirst()
				.orElse(new Person()); //empty person
	}
	
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Integer create(@RequestBody Person resource) {
		Objects.requireNonNull(resource);
		PersonList.persons.add(resource);
		resource.setPersonNum(PersonList.persons.indexOf(resource));
		return resource.getPersonNum();
	}
	
	@PutMapping(value = "/{id}")
	@ResponseStatus(HttpStatus.OK)
	public void update(@PathVariable("id") Integer id, @RequestBody Person resource) {
		Objects.requireNonNull(resource);
		Person p = PersonList.persons.get(id);
		Objects.requireNonNull(p);
		p = resource;
	}
	
	@DeleteMapping(value = "/{id}")
	@ResponseStatus(HttpStatus.OK)
	public void delete(@PathVariable("id") Integer id) {
		PersonList.persons.remove(id.intValue());
	}
}
