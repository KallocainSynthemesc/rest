import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import model.Person;

public class Main {

	public static void main(String[] args) throws JAXBException {
		Person p = new Person(1L, "Kilian", "Schropp", 28 );

		JAXBContext context = JAXBContext.newInstance(Person.class);
		StringWriter writer = new StringWriter();
		context.createMarshaller().marshal(p, writer);
		String xml = writer.toString();
		System.out.println(xml);
	}

}
