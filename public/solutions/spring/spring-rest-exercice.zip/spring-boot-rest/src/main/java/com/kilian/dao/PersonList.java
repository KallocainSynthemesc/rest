package com.kilian.dao;

import java.util.ArrayList;
import java.util.List;

import com.kilian.model.Person;


public class PersonList {
	
	public static List<Person> persons = new ArrayList<Person>();
	
	static {
        persons.add(new Person(1,"Kilian", "Schropp", 28));
        persons.add(new Person(2, "Alice", "Wonderland", 30));
        persons.add(new Person(3, "Bob", "Baumeister", 35));
    }
}
